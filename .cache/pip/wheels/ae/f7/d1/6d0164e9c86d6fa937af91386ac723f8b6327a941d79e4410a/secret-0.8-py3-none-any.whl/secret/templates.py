
statusT = """
VAULT: {}
KEY: {}
PROJECT: {} 
ENV: {}
AWS/profile? {}
AWS/key? {}
AWS/secret? {}"""

helpT = """
1. Run setup
2. Check that AWS environment variables for profile OR key+secret are set
"""
