# -*- coding: utf-8 -*-
# Author: Koos Zevenhoven

# Needs to do some magic to import numpy and replace it with a monkey-patched
# version implementing __getitem__ etc. This seems to be close to the cleanest
# way to do this in Python. This now works best with Python >=3.5

import np.magic
