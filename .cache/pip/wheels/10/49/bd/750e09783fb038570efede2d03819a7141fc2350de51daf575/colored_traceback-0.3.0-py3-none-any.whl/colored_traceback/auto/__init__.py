from colored_traceback import add_hook
add_hook()
